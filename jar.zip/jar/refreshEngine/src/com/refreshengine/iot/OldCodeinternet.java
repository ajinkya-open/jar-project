package com.refreshengine.iot;

import java.net.URL;
import java.net.URLConnection;
import java.sql.Timestamp;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class OldCodeinternet implements MqttCallback {

	private static String topic;
	private static Thread t1;
	MqttClient client;
	private OldCodeinternet internetOnOff;
	private static boolean connectedToInternet = false;
	private static boolean flag;
	private static long refreshIntervalUpdate = 1000;
	private static String urlAws;

	public OldCodeinternet() {
	}

	public static void main(String[] args) {
		new OldCodeinternet().startInternet("hub1_baner_4", 500, "tcp://geniewish.genieiot.com:1883");
	}

	public void startInternet(String topicName, long intervalUpdate, String urlToConnectAws) {
		topic = topicName;
		refreshIntervalUpdate = intervalUpdate;
		urlAws = urlToConnectAws;
		System.out.println("Subscribed to topic\t" + topic);
		getCurrentObject().setMqttCallBack();
		t1 = new Thread(new Runnable() {

			public void run() {
				synchronized (t1) {
					while (true) {
						try {
							URL url = new URL("http://www.google.com");
							URLConnection connection = url.openConnection();
							connection.connect();
							connectedToInternet = true;
							flag = false;
						} catch (Exception e) {
							connectedToInternet = false;
							if (!flag && !connectedToInternet) {
								flag = true;
								Timestamp timestamp = new Timestamp(System.currentTimeMillis());
								System.out.println("Disconnected from aws\t" + timestamp + "\nretrying...");
							}
							try {
								Thread.sleep(refreshIntervalUpdate);
							} catch (InterruptedException e1) {
							}
							getCurrentObject().setMqttCallBack();
						}
					}
				}
			}

		});
		t1.start();

	}

	private void setMqttCallBack() {
		try {
			client = new MqttClient(urlAws, "internet_" + topic);
			MqttConnectOptions connOpts = new MqttConnectOptions();
			connOpts.setCleanSession(true);
			client.connect(connOpts);
			client.setCallback(this);
			client.subscribe(topic);
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			System.out.println("Connected to aws     \t" + timestamp);
			connectedToInternet = true;
		} catch (MqttException e) {
		}
	}

	Integer genrateRandomNumber() {
		Integer number = 99 + (int) (Math.random() * ((4999999 - 99) + 1));
		return number;
	}

	public void connectionLost(Throwable cause) {
		try {
			Thread.sleep(refreshIntervalUpdate);
			System.out.println("Mqtt" + cause.getMessage());
			getCurrentObject().setMqttCallBack();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private OldCodeinternet getCurrentObject() {
		if (internetOnOff == null) {
			internetOnOff = new OldCodeinternet();
			return internetOnOff;
		}
		return internetOnOff;
	}

	public void messageArrived(String topic, MqttMessage message) throws Exception {
		String[] data = message.toString().split(",");
		switch (data[0]) {
		case "wish":
//			MqttMessage wishCommand = new MqttMessage(data[2].getBytes());
//			try {
//				message.setQos(2);
//				MqttInternetConnection.getMqttConnection().publish(data[1], wishCommand);
//				System.out.println("switch on:\t" + data[0] + "\t" + data[1] + "\t" + data[2] + "\t" + topic);
//			} catch (MqttPersistenceException e1) {
//			} catch (MqttException e1) {
//			}
//			break;
		case "update":
			System.out.println("doing frimware update...");
			break;
		case "synch":
			System.out.println("doing synching...");
			break;
		case "usage":
			System.out.println("doing usage...");
			break;
		case "extra":
			System.out.println("doing extra stuff...");
			break;
		case "test":
			System.out.println("doing extra stuff...");
			break;
		default:
			System.out.println(message);
			break;
		}
	}

	public void deliveryComplete(IMqttDeliveryToken token) {
		System.out.println("deliveryComplete");
	}
}