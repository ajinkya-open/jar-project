package com.refreshengine.iot;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.swing.SwingUtilities;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONException;
import org.json.JSONObject;

import com.refreshengine.iot.constants.Constant;
import com.refreshengine.iot.utility.FCMNotifier;
import com.refreshengine.iot.utility.JDBCConnection;
import com.refreshengine.iot.utility.MqttConnection;
import com.refreshengine.iot.utility.Utility;

/**
 * This LocalCallBcak set callBcaks to local panels 1) Set local callbacks to
 * the all physical panels (Genie rectangle). This listen on refresh topic and
 * then republish on refreshBack topic so that we can notify mobile phones when
 * user perform physical switch operations.
 *
 * @author Swapnil B Bhosale
 * @version 1.0
 * @since 1-Jan-2017
 */

public class LocalCallBack implements MqttCallback {

	private static LocalCallBack currentObject;
	private static Integer switchCount;
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:00");
	private static String oldMessage = "";

	public void setCallBackLocal() {

		Properties prop = new Properties();
		InputStream input = null;
		try {
			input = new FileInputStream("config.properties");
			prop.load(input);
			MemoryPersistence memoryPersistence = new MemoryPersistence();
			String clientId = "genieClientId_" + System.currentTimeMillis() % 1002;
			MqttClient client = new MqttClient(prop.getProperty("localBroker"), clientId, memoryPersistence);
			MqttConnectOptions connectOptions = new MqttConnectOptions();
			connectOptions.setCleanSession(true);
			client.connect();
			client.setCallback(this);
			client.subscribe(prop.getProperty("physicalSwTopic"));
			System.out.println("Subscribed to topic \t" + prop.getProperty("physicalSwTopic") + "\t"
					+ new Timestamp(System.currentTimeMillis()));
		} catch (IOException ex) {
		} catch (MqttException e) {
			/*
			 * Problem local web service is down or not connected or crashed
			 * Reporting to AWS regarding this
			 */
			System.out.println("Big problem local web service is down or not connected or crashed" + "\t"
					+ new Timestamp(System.currentTimeMillis()));
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void connectionLost(Throwable arg0) {
		try {
			System.out.println("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Local Connection lost <<<<<<<<<<<<<<<<<<<<<<<<<" + "\t"
					+ new Timestamp(System.currentTimeMillis()));
			Thread.sleep(10000);
			getCurrentObj().setCallBackLocal();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static LocalCallBack getCurrentObj() {
		if (currentObject == null) {
			currentObject = new LocalCallBack();
			return currentObject;
		}
		return currentObject;
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken arg0) {

	}

	@Override
	public void messageArrived(String arg0, MqttMessage message) {
		
		if (!oldMessage.equals(message.toString())) {
			oldMessage = message.toString();
			SwingUtilities.invokeLater(new Runnable() {
				@SuppressWarnings("deprecation")
				@Override
				public void run() {
					String switchName = "";
					String roomName = "";

					JSONObject jMessage = new JSONObject();
					
					try {
						String activityMessage = "Physically switch ";
						String dimmerValue = "0";
						String switchStatus = "0";
						//String dimmerStatus = "0";
						byte[] b = message.toString().getBytes();
						StringBuffer topicName = new StringBuffer();

						for (int i = 5; i < b.length; i++)
							topicName.append((char) b[i]);
						if ((char) b[2] == 'p' && (char) b[3] == 'q') {
							// from switch
							if (b[1] == 42) {
								if (b[0] == 5 || b[0] == 6) {
									// dimmer off
									System.out.println("Dimmer Switch no " + b[0] + " is off (" + topicName + ")" + "\t"
											+ new Timestamp(System.currentTimeMillis()));
									activityMessage = activityMessage + "off ";
									dimmerValue = switchStatus = "0";
									//dimmerStatus = "1";
								} else {
									// switch off
									System.out.println("Switch no " + b[0] + " is off (" + topicName + ")" + "\t"
											+ new Timestamp(System.currentTimeMillis()));
									dimmerValue = switchStatus = "0";
									//dimmerStatus = "0";
									activityMessage = activityMessage + "off ";
								}
							} else if (b[1] == 1) {
								// switch on
								System.out.println("Switch no " + b[0] + " is on (" + topicName + ")" + "\t"
										+ new Timestamp(System.currentTimeMillis()));
								switchStatus = "1";
								dimmerValue = "0";
								activityMessage = activityMessage + "on ";
							} else {
								// dimmer on
								System.out.println("Dimmer Switch no " + b[0] + " is on and value is " + b[1] + " ("
										+ topicName + ")" + "\t" + new Timestamp(System.currentTimeMillis()));
								switchStatus = "1";
								//dimmerStatus = "1";
								//dimmer value should not go above 75
								if(b[1] > 70){
									dimmerValue = 75 + "";
								}else{
									dimmerValue = b[1] + "";
								}
								activityMessage = activityMessage + "on ";
							}
						} else {
							// From ^ to
							StringBuffer connectedOrNot = new StringBuffer();
							for (int i = 0; i < b.length; i++)
								connectedOrNot.append((char) b[i]);
							if (!connectedOrNot.toString().contains("con")) {
								String switchStatusString = Integer.toBinaryString(b[0]);
								JSONObject jsonMessage = new JSONObject();
								switchCount = 6;
								for (Integer i = switchStatusString.length() - 2; i >= 0; i--) {
									try {
										char charAt = switchStatusString.charAt(i);
										jsonMessage.put(switchCount.toString(), Character.toString(charAt));
										switchCount--;
									} catch (Exception exception) {
										System.out.println("Exceptoin: " + exception + "\t"
												+ new Timestamp(System.currentTimeMillis()));
									}
								}
								// Dimmer values
								jsonMessage.put("5dim", b[1]);
								jsonMessage.put("6dim", b[2]);
								System.out.println("^\t" + jsonMessage);
							} else
								System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!! panel connected name: "
										+ connectedOrNot.toString().replace("con", "")
										+ " !!!!!!!!!!!!!!!!!!!!!!!!!!!!!" + "\t"
										+ new Timestamp(System.currentTimeMillis()));
						}

						// First get switch id
						int switch_no = b[0];
						// System.out.println(topicName.toString());

						Statement statement = JDBCConnection.getConnection().createStatement();
						String sqlUpdateQuery = "SELECT S.id,S.dimmer_status,S.dimmer_value,S.hide_status,S.lock_status,"
								+ "S.switch_identifier,S.switch_name,S.switch_number,S.switch_status,S.switch_type,R.id as 'roomid', R.homeid as 'homeid',R.room_name FROM switch S "
								+ "LEFT JOIN iotproduct I ON S.iotproductid=I.id  LEFT JOIN panel p ON p.panel_id=I.iot_product_number  LEFT JOIN room R ON R.id=I.roomid "
								+ "  where p.panel_name =" + "'" + topicName.toString() + "'" + "AND S.switch_number = "
								+ switch_no;

						ResultSet resultSet = statement.executeQuery(sqlUpdateQuery);
						
						while (resultSet.next()) {
							switchName = resultSet.getString("switch_name");
							activityMessage = activityMessage + switchName;
							roomName = resultSet.getString("room_name");
							String switch_number = resultSet.getString("switch_number");
							int switchid = Integer.parseInt(resultSet.getString("id"));

							if (Integer.parseInt(resultSet.getString("lock_status")) == 0 && Integer.parseInt(resultSet.getString("hide_status")) == 0) {
								sqlUpdateQuery = "UPDATE switch " + "SET switch_status = " + "'" + switchStatus + "',"
										+" dimmer_value=" + "'"
										+ dimmerValue + "'" + " WHERE id = " + switchid;

								JDBCConnection.getConnection().createStatement().executeUpdate(sqlUpdateQuery);

								// the mysql insert statement
								String query = " insert into activity (created_date, message, message_type, image, roomname)"
										+ " values (?, ?, ?, ?, ?)";
								java.sql.PreparedStatement preparedStmt = JDBCConnection.getConnection()
										.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
								preparedStmt.setString(1, dateFormat.format(new Date()).toString());
								preparedStmt.setString(2, activityMessage);
								preparedStmt.setString(3, "Physically switch on");
								preparedStmt.setString(4, "");
								preparedStmt.setString(5, roomName);
								int id = 0;
								ResultSet rs = null;

								int rowAffected = preparedStmt.executeUpdate();
								if (rowAffected == 1) {
									// get candidate id
									rs = preparedStmt.getGeneratedKeys();
									if (rs.next())
										id = rs.getInt(1);

								}

								jMessage.put("status", "Switch_ON_OFF");
								jMessage.put("userId", "");
								jMessage.put("username", "");
								jMessage.put("message", activityMessage);
								jMessage.put("switchid", switchid + "");
								jMessage.put("switchnumber", switch_number);
								jMessage.put("switchstatus", switchStatus);
								jMessage.put("switchName", switchName);
								
								//jMessage.put("dimmerstatus", dimmerStatus);
								jMessage.put("dimmervalue", dimmerValue);
								jMessage.put("userimage", "");
								jMessage.put("RoomName", roomName.toString());
								jMessage.put("Time", dateFormat.format(new Date()));
								jMessage.put("activityid", id + "");
								Date dateCurrent = new Date();
								jMessage.put("Time", dateCurrent.getDate() + " " + theMonth(dateCurrent.getMonth())
										+ " "
										+ getTime(dateCurrent.getHours() + ":" + dateCurrent.getMinutes()).toString());

								// System.out.print(jMessage);
								// refreshBackMessage to mobile or to other thin
								// end
								// clients

								MqttMessage refreshBackMessage = new MqttMessage(jMessage.toString().getBytes());
								refreshBackMessage.setQos(2);
								MqttConnection.getMqttConnectionLocal().publish("refreshBack", refreshBackMessage);
								String awsTopic = "intRefreshTopicIntHID_" + Utility.getHomeIdOriginal();
								MqttConnection.getMqttConnectionIntenet().publish(awsTopic, refreshBackMessage);
								System.out.println("geniecentral topic back\t" + awsTopic + "\t"
										+ new Timestamp(System.currentTimeMillis()));
							}
						}
						FCMNotifier.sendNotificationMessage(Constant.PHYSICAL_ON_OFF, jMessage, Constant.ARMED_DISARMED_PHYSICALLY_ON_OFF_MESSAGE);
					} catch (SQLException e) {
						e.printStackTrace();
					} catch (MqttPersistenceException e) {
						e.printStackTrace();
					} catch (MqttException e) {
						e.printStackTrace();
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}

				public String theMonth(int month) {
					String[] monthNames = { "Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sept", "Oct",
							"Nov", "Dec" };
					return monthNames[month];
				}

				public String getTime(String time) {
					String time1 = "";
					try {
						String _24HourTime = time;
						SimpleDateFormat _24HourSDF = new SimpleDateFormat("HH:mm");
						SimpleDateFormat _12HourSDF = new SimpleDateFormat("hh:mm a");
						Date _24HourDt = _24HourSDF.parse(_24HourTime);
						time1 = _12HourSDF.format(_24HourDt);
					} catch (Exception e) {
						e.printStackTrace();
					}
					return time1;
				}
			});
		} else {
			System.out.println(
					"Local call back SAME message ignoring ..." + "\t" + new Timestamp(System.currentTimeMillis()));
		}
	}
}
