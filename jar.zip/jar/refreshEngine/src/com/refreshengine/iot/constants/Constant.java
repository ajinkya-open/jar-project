package com.refreshengine.iot.constants;

public class Constant {

	public static final String FCM_NOTIFIER_URL = "https://fcm.googleapis.com/fcm/send";
	
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String AUTHORIZATION = "Authorization";

	public static final String FCM_NOTIFIER_TITLE = "title";
	public static final String FCM_NOTIFIER_BODY = "body";
	public static final String FCM_NOTIFIER_SOUND = "sound";
	public static final String FCM_NOTIFIER_NOTIFICATION = "notification";
	
	public static final String MESSAGE = "message";
	public static final String FCM_NOTIFIER_TO = "to";
	public static final String FCM_NOTIFIER_DATA = "data";
	public static final String FCM_NOTIFIER_CONTENT_AVAILABLE = "content_available";
	public static final String NOTIFICATION_SERVER_KEY = "AIzaSyDnTWjcMIFuDR_bKfcp1AAkW5xua6x0mlw";

	public static final String ARMED_DISARMED_PHYSICALLY_ON_OFF_MESSAGE = "Intruder Alarm, Someone is physically switching ON_OFF_STATUS your SWITCH_NAME of ROOM_NAME at your home right now. (You are receiving this, because you have switched your home Armed)";
	
	public static final String INTERNET_ON_OFF_MESSAGE = "is currently switching ON or OFF your home appliances via Internet";

	public static final String ARMED_INTERNET = "has turned Home Armed. Your Home is Safe Now, whenever any user does physical Switch ON or OFF you will be notified";
	
	public static final String DISARMED_INTERNET = "has turned Home Unarmed Successfully.";
	
	public static final String PHYSICAL_ON_OFF = "Physical_ON_OFF";
	
	public static final String INTERNET_ON_OFF = "Internet_ON_OFF";
	
}
