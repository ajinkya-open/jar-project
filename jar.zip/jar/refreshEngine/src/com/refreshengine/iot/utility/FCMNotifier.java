package com.refreshengine.iot.utility;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.refreshengine.iot.constants.Constant;

public class FCMNotifier {

	URL url;
	String deviceID;
	HttpURLConnection conn;
	String serverKey;
	HashMap<String, Object> message;

	JsonElement jsonMessage;

	HashMap<String, Object> notification = new HashMap<>();

	boolean success;

	public FCMNotifier(String serverKey, String deviceID) throws Exception {
		url = new URL(Constant.FCM_NOTIFIER_URL);
		conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod("POST");
		conn.setRequestProperty(Constant.CONTENT_TYPE, "application/json");
		this.serverKey = serverKey;
		conn.setRequestProperty(Constant.AUTHORIZATION, "key=" + serverKey);
		message = new HashMap<>();
		this.deviceID = deviceID;
	}

	public void setMessage(String title, Object body) throws Exception {
		HashMap<String, Object> data = new HashMap<>();

		HashMap<String, Object> innerMessage = new HashMap<>();

		innerMessage.put(Constant.FCM_NOTIFIER_TITLE, title);
		innerMessage.put(Constant.FCM_NOTIFIER_BODY, body);

		data.put(Constant.MESSAGE, innerMessage);

		// message.put("priority","normal");
		message.put(Constant.FCM_NOTIFIER_TO, deviceID);
		message.put(Constant.FCM_NOTIFIER_DATA, data);
		message.put(Constant.FCM_NOTIFIER_CONTENT_AVAILABLE, true);

		jsonMessage = new Gson().toJsonTree(message);

	}

	public void setNotification(String title, Object body) throws Exception {
		notification = new HashMap<>();
		// notification.put("title", title);
		notification.put(Constant.FCM_NOTIFIER_BODY, body);
		notification.put(Constant.FCM_NOTIFIER_SOUND, "default");
		// notification.put("badge", count);
		message.put(Constant.FCM_NOTIFIER_NOTIFICATION, notification);
	}

	public boolean sendNotification() throws Exception {
		Thread sendNotificationThread = new Thread() {
			public void run() {
				String response = "Default";

				String output;
				try {

					String input = jsonMessage.toString();

					// logger.info(jsonMessage.toString());

					OutputStream os = conn.getOutputStream();
					os.write(input.getBytes());
					os.flush();

					if (conn.getResponseCode() != HttpURLConnection.HTTP_CREATED) {
						// logger.info("ResponseCode::" +
						// conn.getResponseCode());
						System.out.println("ResponseCode::" + conn.getResponseCode());
					}

					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
					// logger.info("Output from Server .... \n");
					System.out.println("Output from Server .... \n");

					while ((output = br.readLine()) != null) {
						response = response + "\n" + output;
					}
					conn.disconnect();

					if (response.contains("\"success\":1")) {
						success = true;
					}

				} catch (Exception e) {
					e.printStackTrace();
					// logger.info("Exception Message: "+e.getMessage()+"
					// Cause:"+e.getCause());
					System.out.println("Exception Message: " + e.getMessage() + " Cause:" + e.getCause());
					response = e.getMessage();
				}
			};
		};

		sendNotificationThread.start();

		try {
			sendNotificationThread.join();
		} catch (InterruptedException iex) {
			iex.printStackTrace();
		}

		return success;
	}

	public static boolean sendNotificationMessage(String title, JSONObject jsonMessage, String notifyMessage) {
		Boolean status = false;
		String serverKey = Constant.NOTIFICATION_SERVER_KEY;
		try {
			Statement statement = JDBCConnection.getConnection().createStatement();
			String isHomeArmedQuery = "SELECT * FROM home WHERE is_armed = 1";
			ResultSet isHomeArmedResultSet = statement.executeQuery(isHomeArmedQuery);

			if (isHomeArmedResultSet.next()) {

				String sql = "SELECT * FROM user_details";
				ResultSet resultSet = statement.executeQuery(sql);

				String body = "";

				String switchStatus = jsonMessage.getString("switchstatus");
				String switchName = jsonMessage.getString("switchName");
				String roomName = jsonMessage.getString("RoomName");

				/*
				 * notifyMessage.replace("ROOM_NAME", switchName);
				 * 
				 * notifyMessage.replace("SWITCH_NAME", roomName);
				 */

				while (resultSet.next()) {
					String strDeviceId = resultSet.getString("device_id");

					// logger.info("Device ID is: "+strDeviceId);
					System.out.println("Device ID is: " + strDeviceId);

					FCMNotifier fcmNotifier = new FCMNotifier(serverKey, strDeviceId);

					if (switchStatus.equals("0")) {
						body = notifyMessage.replaceAll("ON_OFF_STATUS", "OFF");
						body = body.replaceAll("ROOM_NAME", roomName);
						body = body.replaceAll("SWITCH_NAME", switchName);
					} else {
						body = notifyMessage.replaceAll("ON_OFF_STATUS", "ON");
						body = body.replaceAll("ROOM_NAME", roomName);
						body = body.replaceAll("SWITCH_NAME", switchName);
					}

					System.out.println("***********************8888BODY********************: " + body);

					fcmNotifier.setNotification(title, body);
					fcmNotifier.setMessage(title, "Home Armed");

					status = fcmNotifier.sendNotification();

					System.out.println("Notification Status for home arm: " + status);
				}
			}

			return status;

		} catch (Exception e) {
			System.out.println("Exception in Send Notification Message Method" + e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

	public static boolean sendNotificationMessage(String title, String notifyMessage, JSONObject postJSON) {

		Boolean status = false;
		String serverKey = Constant.NOTIFICATION_SERVER_KEY;
		String userFirstName = "";
		String userLastName = "";

		int iUserId = 0;

		String armed = "";

		try {
			iUserId = postJSON.getInt("userId");
			armed = postJSON.getString("isArmed");

			if (armed.equals("1")) {
				notifyMessage += Constant.ARMED_INTERNET;
				System.out.println("Armed internet Armed value: " + armed);
			} else {
				notifyMessage += Constant.DISARMED_INTERNET;
				System.out.println("Disarmed internet Disarmed value: " + armed);
			}

		} catch (JSONException e) {
			if (iUserId == 0) {
				try {
					iUserId = postJSON.getInt("userid");
				} catch (JSONException e1) {
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
		}

		if (title.equalsIgnoreCase("Internet_ON_OFF")) {
			System.out.println("Somebody is switching On or Off via internet");

			Statement statement;
			try {
				statement = JDBCConnection.getConnection().createStatement();

				// get user who is doing it
				String sql = "SELECT * FROM user_details WHERE id = " + iUserId;
				ResultSet resultSet = statement.executeQuery(sql);

				System.out.println("User Id: " + iUserId + "***********************");

				while (resultSet.next()) {
					userFirstName = resultSet.getString("first_name");
					userLastName = resultSet.getString("last_name");

				}

				// send notification to all home members
				String allUserQuery = "SELECT * FROM user_details";
				ResultSet alluserResultSet = statement.executeQuery(allUserQuery);

				while (alluserResultSet.next()) {
					// String strDeviceId =
					// alluserResultSet.getString("device_id");
					String strDeviceId = Utility.getDeviceId();

					System.out.println("Device ID is: " + strDeviceId);

					FCMNotifier fcmNotifier;
					try {
						fcmNotifier = new FCMNotifier(serverKey, strDeviceId);

						String body = "";

						body += userFirstName + " " + userLastName + " " + notifyMessage;

						System.out.println("*****************BODY*************************" + body);

						fcmNotifier.setNotification(title, body);
						fcmNotifier.setMessage(title, "Internet_ON_OFF");

						status = fcmNotifier.sendNotification();

						System.out.println("Notification Status for home arm: " + status);

					} catch (Exception e) {
						System.out.println("Exception in FCM Notifier" + e.getMessage());
						e.printStackTrace();
					}
					System.out.println("Notification Status for internet Switch On Off: " + status);
				}

			} catch (Exception e) {
				System.out.println("Exception in SQL Database" + e.getMessage());
				e.printStackTrace();
			}

		}

		return status;
	}

	/*
	 * public static void main(String args[]){ JSONObject json = new
	 * JSONObject();
	 * 
	 * try { json.put("switchstatus", "1"); json.put("switchName", "Tube");
	 * json.put("RoomName","Cabin");
	 * 
	 * } catch (JSONException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); }
	 * 
	 * try { String userId = (String) json.get("userid");
	 * 
	 * //System.out.println("****************"+userId+"****************"+json.
	 * getInt("userId"));
	 * 
	 * } catch (Exception e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); }
	 * 
	 * sendNotificationMessage("Internet_ON_OFF",json,Constant.
	 * ARMED_DISARMED_PHYSICALLY_ON_OFF_MESSAGE); }
	 */
}
