package com.refreshengine.iot.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JDBCConnection {

	static java.sql.Connection connection = null;

	public static java.sql.Connection getConnection() {

		if (connection == null) {
			try {
				Properties prop = new Properties();
				InputStream input = null;
				try {
					Class.forName("com.mysql.jdbc.Driver"); 
					input = new FileInputStream("config.properties");
					prop.load(input);
					connection = DriverManager.getConnection(prop.getProperty("localDbUrl"),
							prop.getProperty("localDbUsername"), prop.getProperty("localDbPassword"));
				} catch (IOException ex) {
					ex.printStackTrace();
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				} finally {
					if (input != null) {
						try {
							input.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			} catch (SQLException exception) {
				System.out.println(exception);
			}
		}
		return connection;
	}
}
