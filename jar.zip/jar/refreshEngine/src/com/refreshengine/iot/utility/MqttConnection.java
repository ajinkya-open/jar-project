package com.refreshengine.iot.utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class MqttConnection {

	private static MqttClient mqttConnectionLocal = null;
	private static MqttClient mqttConnectionInt = null;
	
	public static synchronized MqttClient getMqttConnectionLocal() throws MqttException {
		if (mqttConnectionLocal != null) {
			System.out.println("reusing local connection ...");
			return mqttConnectionLocal;
		} else {
			Properties prop = new Properties();
			InputStream input = null;
			try {
				input = new FileInputStream("config.properties");
				prop.load(input);
				MemoryPersistence persistence = new MemoryPersistence();
				String clientId = "" + System.currentTimeMillis() / 10000;
				mqttConnectionLocal = new MqttClient(prop.getProperty("localBroker"), clientId, persistence);
				MqttConnectOptions connOpts = new MqttConnectOptions();
				connOpts.setCleanSession(true);
				mqttConnectionLocal.connect(connOpts);
				System.out.println("Connected...");
			} catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				if (input != null) {
					try {
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			return mqttConnectionLocal;
		}
	}
	
	public static synchronized MqttClient getMqttConnectionIntenet() throws MqttException {
		if (mqttConnectionInt != null) {
			System.out.println("reusing internet connection ...");
			return mqttConnectionInt;
		} else {
			Properties prop = new Properties();
			InputStream input = null;
			try {
				input = new FileInputStream("config.properties");
				prop.load(input);
				MemoryPersistence persistence = new MemoryPersistence();
				String clientId = "" + System.currentTimeMillis() / 8278;
				mqttConnectionInt = new MqttClient(prop.getProperty("awsBroker"), clientId,
						persistence);
				MqttConnectOptions connOpts = new MqttConnectOptions();
				connOpts.setCleanSession(true);
				mqttConnectionInt.connect(connOpts);
				System.out.println("Connected...");
			} catch (IOException ex) {
				ex.printStackTrace();
			} finally {
				if (input != null) {
					try {
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			return mqttConnectionInt;
		}
	}

}
