package com.refreshengine.iot.utility;

import java.util.TimerTask;

import com.refreshengine.iot.LocalCallBack;

public class ScheduledTaskLocal extends TimerTask {
	public void run() {
		System.out.println("\n******************************* Re subscribing local callback ***************************** ");
		LocalCallBack.getCurrentObj().setCallBackLocal();
	}
}
