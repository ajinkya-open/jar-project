package com.refreshengine.iot.utility;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.TimerTask;

import javax.swing.SwingUtilities;

public class ScheduledTaskRestartApp extends TimerTask {
	public void run() {
		System.out.println("Restarting java jar\t" + new Timestamp(System.currentTimeMillis()));
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				ProcessBuilder processBuilder = new ProcessBuilder("sudo ./res.sh");
				try {
					processBuilder.start();
					System.out.println("jar restarted successfully\t" + new Timestamp(System.currentTimeMillis()));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
		System.exit(0);
	}
}
