package com.refreshengine.iot.utility;

import java.util.TimerTask;

import com.refreshengine.iot.InternetOnOff;

public class ScheduledTaskInternet extends TimerTask{

	public void run() {
		System.out.println("\n******************************* Re subscribing internet callback ***************************** ");
		InternetOnOff.getCurrentObj().setMqttCallBackInt();
	}
}
