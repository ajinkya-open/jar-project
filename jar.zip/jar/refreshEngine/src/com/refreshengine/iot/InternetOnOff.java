package com.refreshengine.iot;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Timestamp;
import java.util.Properties;
import java.util.Timer;
import java.util.logging.Logger;

import javax.swing.SwingUtilities;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONException;
import org.json.JSONObject;

import com.refreshengine.iot.constants.Constant;
import com.refreshengine.iot.utility.FCMNotifier;
import com.refreshengine.iot.utility.ScheduledTaskInternet;
import com.refreshengine.iot.utility.ScheduledTaskLocal;
import com.refreshengine.iot.utility.Utility;

/**
 * This InternetOnOff class set callback to AWS 1) set callback to aws so that
 * we can reach to Genie pyramid through Internet then on message arrived
 * function calls local web services again. (This is just jugad because right
 * now web service guy not able to perform callback in spring boot app)
 *
 * @author Swapnil B Bhosale
 * @version 1.0
 * @since 1-Jan-2017
 */

public class InternetOnOff implements MqttCallback {

	static Logger logger = Logger.getLogger(InternetOnOff.class.getName());

	static String topic;
	private static Thread t1;
	MqttClient client = null;
	private static String oldMessageInt = "";
	private static String awsBroker = null;
	private static String localWebServiceUrl = null;
	private static boolean connectedToInternet = false;
	private static String tockenAuth;
	private static InternetOnOff currentObject;

	public static void main(String[] args) {
		topic = Utility.getHomeId();
		System.out.println("topic local\t" + topic);
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new LocalCallBack().setCallBackLocal();
			}
		});
		new InternetOnOff().startInternet();
		Timer time = new Timer();
		ScheduledTaskLocal taskLocal = new ScheduledTaskLocal();
		time.schedule(taskLocal, 3600000, 3600000);
		ScheduledTaskInternet taskInt = new ScheduledTaskInternet();
		time.schedule(taskInt, 3600000, 3600000);
		// ScheduledTaskRestartApp taskRestartApp = new
		// ScheduledTaskRestartApp();
		// time.schedule(taskRestartApp, 15000, 15000);

	}
	
	// @SuppressWarnings("unused")
	// private static void createPropertyFile() {
	// Properties props = new Properties();
	// // props.setProperty("localBroker", "tcp://localhost:1883");
	// props.setProperty("localBroker", "tcp://192.168.0.119:1883");
	// props.setProperty("awsBroker", "tcp://geniewish.genieiot.com:1883");
	// props.setProperty("physicalSwTopic", "refresh");
	// props.setProperty("callBackMobile", "refreshBack");
	// props.setProperty("localWebServiceUrl",
	// "http://192.168.0.119:8080/GSmart_final_9jan/");
	// // props.setProperty("localWebServiceUrl",
	// // "http://localhost:8080/GSmart_final_9jan/");
	// props.setProperty("localDbUrl",
	// "jdbc:mysql://localhost/geniefinal_1901");
	// props.setProperty("localDbUsername", "root");
	// props.setProperty("localDbPassword", "root");
	// // props.setProperty("awsDbUrl",
	// //
	// "jdbc:mysql://geniedb.cyab3rb5yzef.us-west-2.rds.amazonaws.com/gsmarthome");
	// props.setProperty("awsDbUrl",
	// "jdbc:mysql://preprod.genieiot.com/gsmarthome");
	// props.setProperty("awsDbUsername", "GenieDB");
	// props.setProperty("awsDbPassword", "GenieDB2016");
	// File f = new File("config.properties");
	// try {
	// OutputStream out = new FileOutputStream(f);
	// props.store(out, "This is property file created by Swapnil Bhosale");
	// } catch (FileNotFoundException e) {
	// e.printStackTrace();
	// } catch (IOException e) {
	// e.printStackTrace();
	// }
	// }

	private static String doLogin() throws JSONException, IOException {
		String tocken = null;
		// String url = "http://localhost:8080/GSmart_final_9jan/login";
		JSONObject jsonObject = null;
		String url = "http://localhost:8080/smart_home_local/login";
		JSONObject postJsonData = new JSONObject();
		postJsonData.put("username", "demo.jar@gsmarthome.com");
		postJsonData.put("password", "genieDemo2dfoGh");

		// postJsonData.put("username", "demo.k@mobantica.com");
		// postJsonData.put("password", "1234567");

		try {
			jsonObject = new JSONObject(Utility.postCommanRestApi(url, postJsonData, tockenAuth));
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		if (jsonObject.getString("status").equals("SUCCESS"))
			tocken = jsonObject.getJSONObject("result").getString("token");

		return tocken;
	}

	public void startInternet() {
		setMqttCallBackInt();
		logger.info("\nSubscribed to topic\t" + topic + "\t" + new Timestamp(System.currentTimeMillis()));
		t1 = new Thread(new Runnable() {
			public void run() {
				synchronized (t1) {
					while (true) {
						try {
							URL url = new URL("http://www.google.com");
							URLConnection connection = url.openConnection();
							connection.connect();
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e1) {
								e1.printStackTrace();
							}
							if (!connectedToInternet) {
								setMqttCallBackInt();
							} else {
								connectedToInternet = true;
							}
							Thread.sleep(1500);
						} catch (Exception e) {
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e1) {
								e1.printStackTrace();
							}
							connectedToInternet = false;
							setMqttCallBackInt();
						}
					}
				}
			}
		});
		t1.start();
	}

	private String getAwsBrokerAddress() {
		if (awsBroker == null) {
			Properties prop = new Properties();
			InputStream input = null;
			try {
				input = new FileInputStream("config.properties");
				prop.load(input);
				awsBroker = prop.getProperty("awsBroker");
			} catch (IOException ex) {
				System.out.println("Config file not found\t" + ex);
			} finally {
				if (input != null) {
					try {
						input.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			return awsBroker;
		} else {
			return awsBroker;
		}
	}

	public void setMqttCallBackInt() {
		try {
			// String clientId = "genieClientId_" + Utility.getHomeIdOriginal();
			String clientId = "genieClientId_" + System.currentTimeMillis() % 1000;
			client = new MqttClient(getAwsBrokerAddress(), clientId);
			MqttConnectOptions connOpts = new MqttConnectOptions();
			connOpts.setCleanSession(true);
			client.connect(connOpts);
			client.setCallback(this);
			client.subscribe(topic);
			System.out.println("\nConnected to aws\t" + new Timestamp(System.currentTimeMillis()));
			connectedToInternet = true;
			System.out.println("\nSubscribed to :\t" + topic + "\t" + new Timestamp(System.currentTimeMillis()));
		} catch (MqttException e) {
			connectedToInternet = false;
			System.out.print(".");
		}
	}

	public void connectionLost(Throwable cause) {
		try {
			System.out.println(
					"\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Internet Connection lost <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\t"
							+ new Timestamp(System.currentTimeMillis()));
			setMqttCallBackInt();
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/*
	 * This method is called from AWS on mqtt on publish method and as per
	 * switch case we call local web service on Genie Pyramid
	 */
	public void messageArrived(String topic, MqttMessage message) throws JSONException {
		System.out.println("old message\t" + oldMessageInt);
		System.out.println("New message\t" + message);
		if (!oldMessageInt.equals(message.toString())) {
			oldMessageInt = message.toString();
			SwingUtilities.invokeLater(new Runnable() {

				@Override
				public void run() {
					try {
						tockenAuth = doLogin();
						System.out.println("tocken: " + tockenAuth);
					} catch (JSONException e) {
					} catch (IOException e) {
						System.out.println(
								"\nUnable to perform login big problem\t" + new Timestamp(System.currentTimeMillis()));
						System.out.println(e.getMessage());
						e.printStackTrace();
					} catch (Exception ex) {
						System.out.println(ex.getMessage());
						ex.printStackTrace();
					}

					try {
						String[] data = message.toString().split("\\|");
						String url = getWebServiceUrl();
						JSONObject postJsonData = new JSONObject(data[2]);
						switch (data[0]) {
						case "wish":
							switch (data[1]) {
							case "get_activity":
								System.out
										.println(
												"Internet\t Get Activity List via Internet \t"
														+ Utility.postCommanRestApi(url + "home/getactivitylist",
																postJsonData, tockenAuth)
														+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "delete_share_control":
								System.out
										.println("Internet\t Delete Share Control from local\t"
												+ Utility.postCommanRestApi(url + "user/deletesharecontrol",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "change_curtain_status":
								System.out
										.println("Internet\t Change Curtain Status\t"
												+ Utility.postCommanRestApi(url + "switch/changecurtainstatus",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "arm_home":
								System.out.println("Internet\t Arm the home for Safe Mode \t"
										+ Utility.postCommanRestApi(url + "home/armhome", postJsonData, tockenAuth)
										+ "\t" + new Timestamp(System.currentTimeMillis()));
								FCMNotifier.sendNotificationMessage(Constant.INTERNET_ON_OFF, "", postJsonData);
								break;
							case "hide_room_status":
								System.out.println("Internet\t Change Hide Room Status \t"
										+ Utility.postCommanRestApi(url + "room/hideroom", postJsonData, tockenAuth)
										+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "schedule_profile":
								System.out
										.println("Internet\t Schedule Profile\t"
												+ Utility.postCommanRestApi(url + "schedule/scheduleprofile",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "edit_schedule_profile":
								System.out
										.println("Internet\t Edit Schedule Profile\t"
												+ Utility.postCommanRestApi(url + "schedule/editscheduleprofile",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "delete_schedule_profile":
								System.out.println("Internet\t Delete Schedule Profile\t"
										+ Utility.postCommanRestApi(url + "schedule/deletescheduleprofile",
												postJsonData, tockenAuth)
										+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "add_profile":
								System.out
										.println(
												"Internet\t  Add Profile\t"
														+ Utility.postCommanRestApi(url + "profile/addprofile",
																postJsonData, tockenAuth)
														+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "edit_profile":
								System.out
										.println(
												"Internet\t Edit Profile\t"
														+ Utility.postCommanRestApi(url + "profile/editprofile",
																postJsonData, tockenAuth)
														+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "delete_profile":
								System.out
										.println(
												"Internet\t Delete Profile\t"
														+ Utility.postCommanRestApi(url + "profile/deleteprofile",
																postJsonData, tockenAuth)
														+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "get_profile_list":
								System.out
										.println("Internet\t Get Profile List\t"
												+ Utility.postCommanRestApi(url + "profile/getprofilelist",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "Internet_Switch_On_Off":
								System.out
										.println(
												"Internet\tSwitch on off\t"
														+ Utility.postCommanRestApi(url + "switch/changestatus",
																postJsonData, tockenAuth)
														+ "\t" + new Timestamp(System.currentTimeMillis()));
								// FCMNotifier.sendNotificationMessage(Constant.INTERNET_ON_OFF,Constant.INTERNET_ON_OFF_MESSAGE,
								// postJsonData);
								break;
							case "switch_list_by_user":
								System.out
										.println("Internet\tSwitch list by user\t"
												+ Utility.postCommanRestApi(url + "switch/getswitchbyuser",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "sync_share_control_data":
								System.out
										.println("Internet\t Sync share control data\t"
												+ Utility.postCommanRestApi(url + "user/syncShareControlData",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "roomUpdate":
								System.out.println("Internet\t Room Update\t"
										+ Utility.postCommanRestApi(url + "room/add", postJsonData, tockenAuth) + "\t"
										+ new Timestamp(System.currentTimeMillis()));
								break;
							case "switchUpdate":
								System.out.println("Internet\t Switch Update \t"
										+ Utility.postCommanRestApi(url + "switch/edit", postJsonData, tockenAuth)
										+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "lockStatus":
								System.out
										.println("Internet\t Lock status\t"
												+ Utility.postCommanRestApi(url + "switch/changelockstatus",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "hideStatus":
								System.out
										.println("Internet\tHide status\t"
												+ Utility.postCommanRestApi(url + "switch/changehidestatus",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "get_scheduler_list":
								System.out
										.println("Internet\t Get Schedule List\t"
												+ Utility.postCommanRestApi(url + "schedule/getscheduleswitch",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "scheduleSwitch":
								System.out
										.println("Internet\t Schedule Switch\t"
												+ Utility.postCommanRestApi(url + "schedule/scheduleswitch",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "editScheduler":
								System.out
										.println("Internet\tedit schedule\t"
												+ Utility.postCommanRestApi(url + "schedule/editscheduleswitch",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "deleteScheduler":
								System.out
										.println("Internet\tdelete Scheduler\t"
												+ Utility.postCommanRestApi(url + "schedule/deletescheduleswitch",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "changeStatusByRoom":
								System.out
										.println("Internet\tchange Status By Room\t"
												+ Utility.postCommanRestApi(url + "switch/changeStatusByRoom",
														postJsonData, tockenAuth)
												+ "\t" + new Timestamp(System.currentTimeMillis()));
								// FCMNotifier.sendNotificationMessage(Constant.INTERNET_ON_OFF,Constant.INTERNET_ON_OFF_MESSAGE,postJsonData);
								break;
							case "updateUserType":
								System.out
										.println(
												"Internet\tupdate User Type\t"
														+ Utility.postCommanRestApi(url + "user/updateUserType",
																postJsonData, tockenAuth)
														+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "shareControl":
								System.out.println("Internet\tshare control\t"
										+ Utility.postCommanRestApi(url + "user/shareControl", postJsonData, tockenAuth)
										+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							case "turnOffAll":
								System.out.println("In internet on off\t" + postJsonData);
								System.out
										.println(
												"\nInternet\turn off all\t"
														+ Utility.postCommanRestApi(url + "profile/profileonoff",
																postJsonData, tockenAuth)
														+ "\t" + new Timestamp(System.currentTimeMillis()));
								// FCMNotifier.sendNotificationMessage(Constant.INTERNET_ON_OFF,Constant.INTERNET_ON_OFF_MESSAGE,postJsonData);
								break;
							case "Internet_getRoomListByVendorId":
								System.out.println("In internet on off get All home statsu\t" + postJsonData);
								System.out
										.println(
												"\nInternet\ttrun off all\t"
														+ Utility.postCommanRestApi(url + "room/getlistbyuser",
																postJsonData, tockenAuth)
														+ "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							default:
								System.out.println(
										"Internet\tDefault code" + "\t" + new Timestamp(System.currentTimeMillis()));
								break;
							}
							break;
						case "update":
							System.out.println(
									"doing firmware update..." + "\t" + new Timestamp(System.currentTimeMillis()));
							break;
						case "synch":
							System.out.println("doing synching..." + "\t" + new Timestamp(System.currentTimeMillis()));
							break;
						case "usage":
							System.out.println("doing usage..." + "\t" + new Timestamp(System.currentTimeMillis()));
							break;
						case "extra":
							System.out
									.println("doing extra stuff..." + "\t" + new Timestamp(System.currentTimeMillis()));
							break;
						case "test":
							System.out
									.println("doing extra stuff..." + "\t" + new Timestamp(System.currentTimeMillis()));
							break;
						default:
							System.out.println(
									"default case\t" + message + "\t" + new Timestamp(System.currentTimeMillis()));
							break;
						}
					} catch (Exception exception) {
						exception.printStackTrace();
					} finally {

					}
				}

				private String getWebServiceUrl() {
					if (localWebServiceUrl == null) {
						Properties prop = new Properties();
						InputStream input = null;
						try {
							input = new FileInputStream("config.properties");
							prop.load(input);
							localWebServiceUrl = prop.getProperty("localWebServiceUrl");
							return localWebServiceUrl;
						} catch (IOException ex) {
							ex.printStackTrace();
						} finally {
							if (input != null) {
								try {
									input.close();
								} catch (IOException e) {
									e.printStackTrace();
								}
							}
						}
					}
					return localWebServiceUrl;
				}
			});
		} else {
			System.out
					.println("\nInternet SAME message ignoring ..." + "\t" + new Timestamp(System.currentTimeMillis()));
		}
	}

	public void deliveryComplete(IMqttDeliveryToken token) {
		System.out.println("deliveryComplete");
	}

	public static InternetOnOff getCurrentObj() {
		if (currentObject == null) {
			currentObject = new InternetOnOff();
			return currentObject;
		}
		return currentObject;

	}

}