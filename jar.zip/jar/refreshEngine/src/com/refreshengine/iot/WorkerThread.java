package com.refreshengine.iot;

public class WorkerThread implements Runnable {
	  
    private String command;
    public WorkerThread(String s){
        this.command=s;
    }

    @Override
    public void run() {}

    @Override
    public String toString(){
        return this.command;
    }
}